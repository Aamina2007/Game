const boardElement = document.getElementById('board');
const statusElement = document.getElementById('status');
const resetButton = document.getElementById('reset');
let board = Array(9).fill('');
let currentPlayer = 'X';
let gameActive = true;

function renderBoard() {
  boardElement.innerHTML = '';
  board.forEach((cell, idx) => {
    const cellDiv = document.createElement('div');
    cellDiv.className = 'cell';
    cellDiv.textContent = cell;
    cellDiv.addEventListener('click', () => handleCellClick(idx));
    boardElement.appendChild(cellDiv);
  });
}

function handleCellClick(idx) {
  if (!gameActive || board[idx]) return;
  board[idx] = currentPlayer;
  if (checkWinner()) {
    statusElement.textContent = `Player ${currentPlayer} wins!`;
    gameActive = false;
  } else if (board.every(cell => cell)) {
    statusElement.textContent = "It's a draw!";
    gameActive = false;
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    statusElement.textContent = `Player ${currentPlayer}'s turn`;
  }
  renderBoard();
}

function checkWinner() {
  const winPatterns = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  return winPatterns.some(pattern =>
    pattern.every(idx => board[idx] === currentPlayer)
  );
}

resetButton.addEventListener('click', () => {
  board = Array(9).fill('');
  currentPlayer = 'X';
  gameActive = true;
  statusElement.textContent = `Player ${currentPlayer}'s turn`;
  renderBoard();
});

// Initial render
statusElement.textContent = `Player ${currentPlayer}'s turn`;
renderBoard();